
## Lambdes i streams

  - [ ]  Fer l'exercici [Exercici Lambdes](./ExerciciL.java)  
 